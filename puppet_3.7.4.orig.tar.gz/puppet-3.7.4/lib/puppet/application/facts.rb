require 'puppet/application/indirection_base'

class Puppet::Application::Facts < Puppet::Application::IndirectionBase
end
